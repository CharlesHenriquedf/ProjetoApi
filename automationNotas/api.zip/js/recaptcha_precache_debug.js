(function () {
  chrome.runtime.onMessage.addListener(function (e, n, o) {
    if (e.type == "notifyRecaptchaPrecacheDebugPage") {
      var i = e.dataType;
      var a = e.postData;
      console.log("dataType = ", i);
      console.log("postData = ", a);
      t = a;
      var l = document.getElementById("allTheData");
      l.innerHTML = "";
      if (i == "precachedSolutions") {
        l.appendChild(r(a));
      }
    }
  });
  var e = 110;
  function n(n) {
    var r = document.createElement("table");
    r.border = 1;
    r.createCaption().innerHTML = "Tasks";
    var t = r.insertRow();
    for (var o in n) {
      var a = r.insertRow();
      for (var l in n[o]) {
        if (o == 0) {
          var s = document.createElement("th");
          s.innerHTML = l;
          t.appendChild(s);
          if (l == "endTime") {
            var s = document.createElement("th");
            s.innerHTML = "solvingTime";
            s.style.color = "gray";
            t.appendChild(s);
            var s = document.createElement("th");
            s.innerHTML = "feelsLikeSolvingTime";
            s.style.color = "gray";
            t.appendChild(s);
            var s = document.createElement("th");
            s.innerHTML = "expirationCountdown";
            s.style.color = "gray";
            t.appendChild(s);
          } else if (1) {
          }
        }
        if (l == "taskData") {
          a.insertCell().innerHTML =
            "<b>hostname:</b> " +
            n[o][l].hostname +
            ";<br /> <b>sitekey:</b> " +
            n[o][l].siteKey;
        } else if (l == "solution") {
          a.insertCell().innerHTML =
            typeof n[o][l] == "string"
              ? n[o][l].substring(0, 50) + "..."
              : n[o][l];
        } else if (l == "expired") {
          a.insertCell().innerHTML =
            '<span style="color: ' +
            (n[o][l] ? "Crimson" : "ForestGreen") +
            ';">' +
            n[o][l] +
            "</span>";
        } else if (l == "taskProcessingToContentScriptTime") {
          a.insertCell().innerHTML =
            '<span style="color: ' +
            (n[o][l] ? "ForestGreen" : "Crimson") +
            ';">' +
            n[o][l] +
            "</span>";
        } else if (l == "error") {
          a.insertCell().innerHTML = n[o][l]
            ? '<span style="color: Crimson;">' + n[o][l] + "</span>"
            : "";
        } else if (l == "endTime") {
          a.insertCell().innerHTML = n[o][l];
          a.insertCell().innerHTML =
            (n[o][l] ? n[o][l] : i()) - n[o]["startTime"];
          a.insertCell().innerHTML = n[o]["taskProcessingToContentScriptTime"]
            ? n[o]["taskProcessingToContentScriptTime"] - n[o]["requestTime"]
            : "";
          var c = n[o][l] ? e - (i() - n[o][l]) : 0;
          a.insertCell().innerHTML = c
            ? '<span style="color: ' +
              (c > 0 ? "ForestGreen" : "Crimson") +
              ';">' +
              c +
              "</span>"
            : "";
        } else {
          a.insertCell().innerHTML = n[o][l];
        }
      }
    }
    return r;
  }
  function r(e, r) {
    var t = document.createElement("div");
    for (var o in e) {
      var i = document.createElement("table");
      i.border = 1;
      i.createCaption().innerHTML = o;
      t.appendChild(i);
      var a = i.insertRow();
      var l = i.insertRow();
      for (var s in e[o]) {
        if (s == "tasks") {
          t.appendChild(n(e[o][s]));
        } else {
          var c = l.insertCell();
          var d = document.createElement("th");
          d.innerHTML = s;
          a.appendChild(d);
          if (s == "noCacheRequestsSinceLastSolutionExpiration") {
            c.innerHTML =
              '<span style="color: ' +
              (e[o][s] ? "Crimson" : "ForestGreen") +
              ';">' +
              e[o][s] +
              "</span>";
          } else {
            c.innerHTML = e[o][s];
          }
        }
      }
    }
    return t;
  }
  var t;
  function o(e, n) {
    console.log("CreateTableFromJSON");
    console.log("data = ", e);
    console.log("k = ", n);
    if (n > 0) {
      console.log("ZAEBAL!!!");
      return document.createTextNode("zaebal!");
    }
    var r = [];
    for (var t in e) {
      for (var i in e[t]) {
        if (r.indexOf(i) === -1) {
          r.push(i);
        }
      }
    }
    var a = document.createElement("table");
    a.border = 1;
    var l = a.insertRow(-1);
    for (var t = 0; t < r.length; t++) {
      var s = document.createElement("th");
      s.innerHTML = r[t];
      l.appendChild(s);
    }
    l = a.insertRow(-1);
    for (var t in e) {
      var c = l.insertCell(-1);
      console.log("data[i][col[j]] = ", e[t]);
      console.log("typeof data[i][col[j]] = ", typeof e[t]);
      if (typeof e[t] === "object" && e[t]) {
        c.appendChild(o(e[t], n + 1));
      } else {
        c.innerHTML = e[t];
      }
    }
    return a;
  }
  function i() {
    return Math.floor(Date.now() / 1e3);
  }
})();
