(function () {
  var e = "_recaptchaOnloadMethod";
  if (e) {
    window[e] = function () {
      var e;
      if (grecaptcha) {
        grecaptcha.execute = function (t, a, n) {
          return new Promise((i, r) => {
            a.isEnterprise = n;
            setTimeout(function () {
              window.postMessage(
                {
                  receiver: "recaptchaContentScript",
                  type: "solveRecaptchaV3",
                  siteKey: t,
                  params: a,
                },
                window.location.href
              );
            }, 1e3);
            e = i;
          });
        };
        if (typeof grecaptcha.enterprise !== "undefined") {
          grecaptcha.enterprise.execute = function () {
            var e = Array.from(arguments);
            e.push(true);
            return grecaptcha.execute.apply(this, e);
          };
        }
      }
      window.addEventListener("message", function (t) {
        if (
          !t.data ||
          typeof t.data.receiver == "undefined" ||
          t.data.receiver != "recaptchaObjectInterceptor"
        ) {
          return;
        }
        var a = t.data;
        if (a.type === "recaptchaTaskSolution") {
          taskSolution = t.data.taskSolution;
          if (typeof e === "function") {
            e(taskSolution);
          }
        }
      });
      if (
        typeof lastOriginalOnloadMethodName !== "undefined" &&
        lastOriginalOnloadMethodName &&
        typeof window[lastOriginalOnloadMethodName] === "function"
      ) {
        window[lastOriginalOnloadMethodName].apply(this, arguments);
      }
      return;
    };
  }
})();
